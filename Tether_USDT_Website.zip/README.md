# Tether USDT Website

Responsive Persian/English static website.

## Publish on GitHub Pages
1. Create a public repository.
2. Upload `index.html`, `styles.css`, and `script.js`.
3. Open Settings → Pages.
4. Choose Deploy from a branch, then `main` and `/root`.
5. Save.

Review all token data and links before publishing. The page includes a clear statement that the project is independent and not affiliated with Tether Limited.
